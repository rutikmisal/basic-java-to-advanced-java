package pack2;
public class Sample7
{
	public void show()
	{
		System.out.println("Wellcome to ");
	}
}