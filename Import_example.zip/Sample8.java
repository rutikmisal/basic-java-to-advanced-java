package pack3;
public class Sample8
{
	public void display()
	{
		System.out.println("java");
	}
}