package pack1;
import pack2.*;
import pack3.*;

class import_ex
{
	public static void main(String args[])
	{
		Sample8 s=new Sample8();
		Sample7 s1=new Sample7();
		s1.show();
		s.display();
	}
}